# ref: https://mypy.readthedocs.io/en/stable/cheat_sheet_py3.html
from typing import Sequence, List, Tuple, Dict, Any, Optional, Union, Literal, Callable
from torch import Tensor
from numpy import ndarray